import {EmployeeInsurance,AdvanceRecovery,PayrollOperation} from "../models/PayrollOperations.js";

import { Router } from "express";
import { z } from "zod";
import { PayrollEligibility, PayrollPolicy } from "../models/PayrollExtras.js";
import { Employee } from "../models/index.js";
import SalaryRevision from "../models/EmployeeSalaryRevision.js";
import {
  MonthlyAttendance,
  PayrollDeductionRule,
  PayrollMonth,
  PayrollEntry,
} from "../models/MonthlyPayroll.js";
import { authenticate, permit } from "../middleware/auth.js";
import { asyncHandler as wrap } from "../utils/asyncHandler.js";
import { audit } from "../utils/audit.js";

const router = Router();
router.use(authenticate);

const ym = z.object({
  year: z.coerce.number().int().min(2020).max(2100),
  month: z.coerce.number().int().min(1).max(12),
});

const money = z.number().finite().min(0).max(100000000);
const toPaise = (n) => Math.round(Number(n) * 100);
const round2 = (n) => Math.round((n + Number.EPSILON) * 100) / 100;
const startOf = (y, m) => `${y}-${String(m).padStart(2, "0")}-01`;
const daysOf = (y, m) => new Date(Date.UTC(y, m, 0)).getUTCDate();
const sum = (items) => items.reduce((s, x) => s + x.amountPaise, 0);

const fail = (message, status = 400) =>
  Object.assign(new Error(message), { status });

// Legacy monthly approvals remain locked per employee, without data migration.
// New entries explicitly have status DRAFT, even in an old approved month.
function resolvedStatus(entry, period) {
  if (!entry) return "NOT_PROCESSED";
  if (entry.status === "PENDING_APPROVAL" || entry.status === "APPROVED") return entry.status;
  // Older entries have no status field; approved months lock them.
  if (!entry.status && period?.status === "APPROVED") return "APPROVED";
  if (!entry.status && period?.status === "PENDING_APPROVAL") return "PENDING_APPROVAL";
  return "DRAFT";
}
async function ensureEmployeeWritable(year, month, employeeId) {
  const period = await PayrollMonth.findOne({year, month}).lean();
  if (!period) return;
  const entry = await PayrollEntry.findOne({period:period._id,employee:employeeId}).lean();
  const status = resolvedStatus(entry, period);
  if (status !== "NOT_PROCESSED" && status !== "DRAFT") {
    throw fail("This employee's payroll is submitted or approved and locked",409);
  }
}

// Apply one paid CL against an existing leave day only after at least
// 20 equivalent days of attendance, counting two half-days as one day.
function grantEligibleCasualLeave(a) {
  const worked = Number(a.presentDays || 0) - Number(a.halfDays || 0) * 0.5;
  const alreadyPaid = Number(a.casualLeaveDays || 0);
  const unpaid = Number(a.unpaidLeaveDays || 0);
  if (worked >= 20 && alreadyPaid === 0 &&
      Number(a.paidLeaveDays || 0) === 0 && unpaid >= 1) {
    return {...a,casualLeaveDays:1,paidLeaveDays:1,unpaidLeaveDays:unpaid-1};
  }
  return a;
}
function attendanceCalc(a, calendarDays) {
  const presentDays = Number(a.presentDays || 0);
  const paidLeaveDays = Number(a.paidLeaveDays || 0);
  const unpaidLeaveDays = Number(a.unpaidLeaveDays || 0);
  const casualLeaveDays = Number(a.casualLeaveDays || 0);
  const weeklyOffDays = Number(a.weeklyOffDays || 0);
  const holidayDays = Number(a.holidayDays || 0);
  const lateMarks = Number(a.lateMarks || 0);
  const approvedOverDays = Number(a.approvedOverDays || 0);
  const halfDays = Number(a.halfDays || 0);

  const inputs = [
    presentDays, paidLeaveDays, unpaidLeaveDays,
    casualLeaveDays, weeklyOffDays, holidayDays,
    lateMarks, halfDays, approvedOverDays,
  ];

  if (inputs.some(v => !Number.isFinite(v) || v < 0)) {
    throw fail("Attendance numbers must be valid and nonnegative");
  }

  if (!Number.isInteger(halfDays) || halfDays > presentDays) {
    throw fail("Half days must be whole numbers and cannot exceed present days");
  }

  if (!Number.isInteger(lateMarks)) {
    throw fail("Late marks must be whole numbers");
  }

  const allocated =
    presentDays + paidLeaveDays + unpaidLeaveDays +
    weeklyOffDays + holidayDays;

  if (Math.abs(allocated - calendarDays) > 0.000001) {
    throw fail(`Attendance must total ${calendarDays} days`);
  }

  if (paidLeaveDays !== casualLeaveDays) {
    throw fail("Paid leave must equal casual leave");
  }
  
  // ============================================
  // CASUAL LEAVE ELIGIBILITY VALIDATION
  // Minimum 20 actual working days = 1 paid CL
  // ============================================

  const actualWorkedDays = presentDays - (halfDays * 0.5);

  const allowedCasualLeave =
    actualWorkedDays >= 20 ? 1 : 0;

  if (!Number.isInteger(casualLeaveDays) || !Number.isInteger(paidLeaveDays)) {
    throw fail("Casual leave must be either 0 or 1 whole day");
  }
  if (casualLeaveDays > allowedCasualLeave) {
    throw fail(
      actualWorkedDays < 20
        ? `Casual Leave not allowed. Employee worked only ${actualWorkedDays} days. Minimum 20 working days required.`
        : "Maximum 1 paid Casual Leave is allowed per month."
    );
  }
 

  const latePenaltyDays = lateMarks * 0.25;
  const halfDayPenaltyDays = halfDays * 0.5;
  const totalDeductionDays = round2(
    unpaidLeaveDays + latePenaltyDays + halfDayPenaltyDays
  );

  const payableBeforeOvertime = round2(
    presentDays + paidLeaveDays +
    weeklyOffDays + holidayDays - latePenaltyDays - halfDayPenaltyDays
  );

  const payableDays = round2(
    payableBeforeOvertime + approvedOverDays
  );

  if (
    payableBeforeOvertime < 0 ||
    payableDays < 0 ||
    payableDays > calendarDays + approvedOverDays
  ) {
    throw fail("Invalid payable days");
  }

  return {
    calendarDays,
    presentDays,
    paidLeaveDays,
    unpaidLeaveDays,
    casualLeaveDays,
    casualLeaveEligible: actualWorkedDays >= 20,
    workedEquivalentDays: actualWorkedDays,
    totalLeaves: paidLeaveDays + unpaidLeaveDays,
    weeklyOffDays,
    holidayDays,
    lateMarks,
    halfDays,
    halfDayPenaltyDays,
    latePenaltyDays,
    totalDeductionDays,
    approvedOverDays,
    payableBeforeOvertime,
    payableDays,
  };
}

// ====================================================
// ATTENDANCE APIs
// ====================================================

router.get("/attendance", permit("employee:read"), wrap(async (req, res) => {
  const { year, month } = ym.parse(req.query);
  const rows = await MonthlyAttendance.find({ year, month })
    .populate("employee", "employeeCode firstName lastName")
    .lean();
  res.json(rows);
}));

router.put(
  "/attendance/:employeeId",
  permit("employee:write"),
  wrap(async (req, res) => {
    const data = ym.extend({
      presentDays: z.number().finite().min(0),
      paidLeaveDays: z.number().finite().min(0).default(0),
      unpaidLeaveDays: z.number().finite().min(0).default(0),
      casualLeaveDays: z.number().finite().min(0).default(0),
      weeklyOffDays: z.number().finite().min(0).default(0),
      holidayDays: z.number().finite().min(0).default(0),
      lateMarks: z.number().int().min(0).default(0),
      halfDays: z.number().int().min(0).default(0),
      approvedOverDays: z.number().finite().min(0).max(31).default(0),
      notes: z.string().max(500).optional(),
    }).parse(req.body);

    await ensureEmployeeWritable(data.year, data.month, req.params.employeeId);

    if (data.approvedOverDays > 0 && req.user.role.code !== "ADMIN") {
      return res.status(403).json({
        message: "Admin must approve overtime days",
      });
    }

    const exists = await Employee.exists({ _id: req.params.employeeId });
    if (!exists) {
      return res.status(404).json({ message: "Employee not found" });
    }

    // One paid CL is applied to an existing leave day after 20 equivalent
    // days actually worked (two half-days count as one). Never create an
    // extra attendance day or overwrite a locked employee payroll.
    Object.assign(data, grantEligibleCasualLeave(data));
    const calculation = attendanceCalc(
      data,
      daysOf(data.year, data.month)
    );

    const doc = await MonthlyAttendance.findOneAndUpdate(
      {
        employee: req.params.employeeId,
        year: data.year,
        month: data.month,
      },
      { $set: { ...data, updatedBy: req.user.id } },
      { upsert: true, new: true, runValidators: true }
    );

    await audit(
      req, "UPSERT", "MonthlyAttendance", doc.id,
      null, { payableDays: calculation.payableDays }
    );

    res.json({ ...doc.toObject(), calculation });
  })
);

// Old monetary overtime endpoints disabled.
router.get("/overtime", permit("employee:read"), wrap(async (_req, res) => {
  res.json([]);
}));

router.put("/overtime/:employeeId", permit("employee:write"), (_req, res) => {
  res.status(410).json({
    message: "Use approved overtime days in attendance",
  });
});

router.post("/overtime/:id/approve", permit("salary:write"), (_req, res) => {
  res.status(410).json({
    message: "Separate overtime payment is discontinued",
  });
});

// ====================================================
// DEDUCTION RULES
// ====================================================

router.get(
  "/deduction-rules",
  permit("config:read"),
  wrap(async (_req, res) => {
    res.json(await PayrollDeductionRule.find().sort({ code: 1 }).lean());
  })
);

router.post(
  "/deduction-rules",
  permit("config:write"),
  wrap(async (req, res) => {
    const data = z.object({
      code: z.string().regex(/^[A-Z0-9_]{2,30}$/),
      name: z.string().min(2),
      mode: z.enum(["FIXED", "PERCENT_GROSS"]),
      value: money,
      effectiveFrom: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
      effectiveTo: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
      enabled: z.boolean().default(true),
      notes: z.string().optional(),
    }).parse(req.body);

    if (data.mode === "PERCENT_GROSS" && data.value > 100) {
      return res.status(400).json({
        message: "Percentage cannot exceed 100",
      });
    }

    const doc = await PayrollDeductionRule.create(data);
    await audit(req, "CREATE", "DeductionRule", doc.id, null, data);
    res.status(201).json(doc);
  })
);

// ====================================================
// PAYROLL PERIOD APIs
// ====================================================

router.get("/periods", permit("employee:read"), wrap(async (_req, res) => {
  res.json(
    await PayrollMonth.find()
      .sort({ year: -1, month: -1 })
      .limit(100)
      .lean()
  );
}));

router.get(
  "/period/:year/:month",
  permit("employee:read"),
  wrap(async (req, res) => {
    const { year, month } = ym.parse(req.params);
    const period = await PayrollMonth.findOne({ year, month });
    const entries = period
      ? await PayrollEntry.find({ period: period.id })
          .sort({ employeeCode: 1 })
          .lean()
      : [];
    const annotatedEntries = entries.map(entry => ({
      ...entry, status: resolvedStatus(entry, period)
    }));
    res.json({ period, entries: annotatedEntries });
  })
);

// ====================================================
// CALCULATE PAYROLL — CTC INCLUSIVE OF EMPLOYER PF
// ====================================================

router.post(
  "/calculate",
  permit("salary:write"),
  wrap(async (req, res) => {
    const { year, month } = ym.parse(req.body);
    // Explicit employee selection is mandatory to protect other employees.
    const employeeId = z.string().regex(/^[0-9a-fA-F]{24}$/).parse(req.body.employeeId);
    await ensureEmployeeWritable(year, month, employeeId);

    const start = startOf(year, month);
    const calendarDays = daysOf(year, month);
const policy = await PayrollPolicy.findOne({
  enabled: true,
})
  .sort({
    createdAt: -1,
    _id: -1,
  })
  .lean();
    

    if (!policy) {
      return res.status(400).json({
        message: "No active payroll policy for selected month",
      });
    }

    const rules = await PayrollDeductionRule.find({
      enabled: true,
      effectiveFrom: { $lte: start },
      $or: [
        { effectiveTo: { $exists: false } },
        { effectiveTo: null },
        { effectiveTo: { $gte: start } },
      ],
    }).lean();

    const employees = await Employee.find({ status: "ACTIVE", _id: employeeId }).lean();
    if (!employees.length) throw fail("Active employee not found",404);

    const period = await PayrollMonth.findOneAndUpdate(
      { year, month },
      { $setOnInsert: { status: "DRAFT" } },
      { upsert: true, new: true }
    );

    let calculated = 0;
    const skipped = [];

    for (const employee of employees) {
      const [salary, attendance, eligibility] = await Promise.all([
        SalaryRevision.findOne({
          employee: employee._id,
          effectiveFrom: { $lte: start },
        }).sort({ effectiveFrom: -1 }).lean(),

        MonthlyAttendance.findOne({
          employee: employee._id, year, month,
        }).lean(),

        PayrollEligibility.findOne({
          employee: employee._id,
        }).lean(),
      ]);

      if (!salary || !attendance) {
        skipped.push({
          employeeCode: employee.employeeCode,
          reason: !salary ? "No salary structure" : "No attendance",
        });
        continue;
      }

      let a;
      try {
        const normalizedAttendance = grantEligibleCasualLeave(attendance);
        a = attendanceCalc(normalizedAttendance, calendarDays);
      } catch (error) {
        skipped.push({
          employeeCode: employee.employeeCode,
          reason: error.message,
        });
        continue;
      }

      // Salary structure's five amounts are a CTC budget.
      // First prorate that budget by payable days.
      const components = salary.items.map(item => {
        const monthlyPaise = toPaise(item.amount.toString());
        const earnedPaise = item.proratable
          ? Math.round(monthlyPaise * a.payableDays / calendarDays)
          : monthlyPaise;

        return {
          code: item.code,
          name: item.name,
          amountPaise: earnedPaise,
        };
      });

      const earnedCtcPaise = sum(components);

      const basic = components
        .filter(x => String(x.code).toUpperCase() === "BASIC")
        .reduce((s, x) => s + x.amountPaise, 0);

      const deductions = [];
      const employerContributions = [];

      let employeePf = 0;
      let employerPf = 0;

      if (eligibility?.pf) {
        if (basic <= 0) {
          skipped.push({
            employeeCode: employee.employeeCode,
            reason: "BASIC salary component missing",
          });
          continue;
        }

        employeePf = Math.round(
          basic * Number(policy.employeePfRate) / 100
        );

        employerPf = Math.round(
          basic * Number(policy.employerPfRate) / 100
        );

        deductions.push({
          code: "PF",
          name: "Employee PF",
          amountPaise: employeePf,
        });

        employerContributions.push({
          code: "EMPLOYER_PF",
          name: "Employer PF (included in CTC)",
          amountPaise: employerPf,
        });
      }

      // Reconcile the employer PF within CTC by adjusting
      // the OTHER allowance, while keeping BASIC unchanged.
      //
      // Do not represent employer PF as a wage deduction.
      const other = components.find(
        x => String(x.code).toUpperCase() === "OTHER"
      );

      if (employerPf > 0) {
        if (!other || other.amountPaise < employerPf) {
          skipped.push({
            employeeCode: employee.employeeCode,
            reason:
              "OTHER allowance is insufficient to absorb employer PF. " +
              "Review this employee's CTC structure.",
          });
          continue;
        }

        other.amountPaise -= employerPf;
      }

      // Components now reflect employee's actual gross
      // earnings rather than inclusive CTC.
      const earnedGrossPaise = sum(components);

      // Employer ESIC is not automatically removed from
      // CTC in this simplified structure. Flag ESIC-eligible
      // cases until CTC allocation is properly configured.
      if (eligibility?.esic) {
        skipped.push({
          employeeCode: employee.employeeCode,
          reason:
            "ESIC-eligible CTC requires separate employer ESIC " +
            "allocation before calculation",
        });
        continue;
      }

    if (eligibility?.pt) {
  const gender = String(employee.gender || "")
    .trim()
    .toUpperCase();

  if (gender === "MALE") {
    deductions.push({
      code: "PT",
      name: "Professional Tax",
      amountPaise: toPaise(policy.ptAmount),
    });
  } else if (gender !== "FEMALE") {
    skipped.push({
      employeeCode: employee.employeeCode,
      reason: "Employee gender must be Male or Female to validate PT",
    });
    continue;
  }
}

      if (eligibility?.tds) {
        deductions.push({
          code: "TDS",
          name: "Approved TDS",
          amountPaise: Number(eligibility.tdsAmountPaise || 0),
        });
      }

      const excluded = new Set([
        "PF", "EMPLOYER_PF", "ESIC",
        "EMPLOYER_ESIC", "PT", "TDS", "INSURANCE", "ADVANCE_RECOVERY", "SITE_LATE", "EARLY_LEAVE",
      ]);

      for (const rule of rules) {
        if (excluded.has(String(rule.code).toUpperCase())) continue;

        const amountPaise = rule.mode === "FIXED"
          ? toPaise(rule.value)
          : Math.round(
              earnedGrossPaise * Number(rule.value) / 100
            );

        deductions.push({
          code: rule.code,
          name: rule.name,
          amountPaise,
        });
      }

      // Additional approved operational records are additive to the existing
      // salary/CTC logic. TA is deliberately excluded from payroll.
      const periodStart = startOf(year, month);
      const periodEnd = `${year}-${String(month).padStart(2, "0")}-${String(calendarDays).padStart(2, "0")}`;
      const [insurance, recoveries, operations] = await Promise.all([
        EmployeeInsurance.findOne({employee:employee._id,active:true,effectiveFrom:{$lte:periodEnd},$or:[{effectiveTo:null},{effectiveTo:{$exists:false}},{effectiveTo:{$gte:periodStart}}]}).sort({effectiveFrom:-1}).lean(),
        AdvanceRecovery.find({employee:employee._id,year,month,status:"APPROVED"}).lean(),
        PayrollOperation.find({employee:employee._id,date:{$gte:periodStart,$lte:periodEnd},status:"APPROVED"}).sort({date:1}).lean(),
      ]);
      if (insurance?.amountPaise) deductions.push({code:"INSURANCE",name:"Employee insurance",amountPaise:insurance.amountPaise});
      const advancePaise = recoveries.reduce((v,r)=>v+r.amountPaise,0);
      if (advancePaise) deductions.push({code:"ADVANCE_RECOVERY",name:"Approved advance recovery",amountPaise:advancePaise});
      // OT starts after 20:00; rate = monthly BASIC / (26 x 8), 1x.
      // An explicit hours value is required, with an approved site record.
      const monthlyBasicPaise = salary.items.filter(i=>String(i.code).toUpperCase()==="BASIC").reduce((v,i)=>v+toPaise(i.amount.toString()),0);
      if(a.approvedOverDays>0 && operations.some(o=>o.type==="OVERTIME")){
        skipped.push({employeeCode:employee.employeeCode,reason:"Both legacy overtime days and hourly overtime exist; resolve duplicate overtime before calculating"});
        continue;
      }
      const overtimePaise = operations.filter(o=>o.type==="OVERTIME").reduce((v,o)=>v+Math.round(monthlyBasicPaise*o.hours/(26*8)),0);
      // Eligible days are counted per trip, including earlier months.
      // Sundays never count toward the first four eligible days or allowance.
      const tripIds = [...new Set(operations.filter(o=>o.type==="OUTSTATION").map(o=>o.tripId).filter(Boolean))];
      const historicalTripDays = tripIds.length ? await PayrollOperation.find({employee:employee._id,type:"OUTSTATION",status:"APPROVED",tripId:{$in:tripIds},date:{$lte:periodEnd}}).sort({date:1}).lean() : [];
      const tripDayRanks = new Map();
      const eligibleTripDays = new Set();
      for(const o of historicalTripDays){
        if(new Date(o.date+"T00:00:00Z").getUTCDay()===0)continue;
        const n=(tripDayRanks.get(o.tripId)||0)+1;
        tripDayRanks.set(o.tripId,n);
        if(n>4)eligibleTripDays.add(String(o._id));
      }
      const outstationCount = operations.filter(o=>o.type==="OUTSTATION"&&eligibleTripDays.has(String(o._id))).length;
      const monthlyCtcPaise = toPaise(salary.monthlyGross.toString());
      const monthlyEmployerPfPaise = eligibility?.pf ? Math.round(monthlyBasicPaise*Number(policy.employerPfRate)/100) : 0;
      const monthlyGrossForOutstation = monthlyCtcPaise-monthlyEmployerPfPaise;
      const outstationPaise = Math.round(outstationCount*0.20*monthlyGrossForOutstation/calendarDays);
      // First two approved early leaves are free; 3rd+ are 25% daily gross.
      const earlyCount = operations.filter(o=>o.type==="EARLY_LEAVE").length;
      const earlyPenaltyPaise = Math.round(Math.max(0,earlyCount-2)*0.25*earnedGrossPaise/calendarDays);
      if(earlyPenaltyPaise) deductions.push({code:"EARLY_LEAVE",name:"Approved early-leave penalty",amountPaise:earlyPenaltyPaise});
      const sitePenaltyPaise = operations.filter(o=>o.type==="SITE_LATE").reduce((v,o)=>v+o.amountPaise,0);
      if(sitePenaltyPaise) deductions.push({code:"SITE_LATE",name:"Approved site late penalty",amountPaise:sitePenaltyPaise});
      const extraEarningsPaise = overtimePaise+outstationPaise;
      const totalDeductionPaise = sum(deductions);
      const netPaise = earnedGrossPaise + extraEarningsPaise - totalDeductionPaise;

      if (netPaise < 0) {
        skipped.push({
          employeeCode: employee.employeeCode,
          reason: "Employee deductions exceed gross earnings",
        });
        continue;
      }

      const existingEntry = await PayrollEntry.findOne({
        period: period.id, employee: employee._id
      }).lean();
      if (resolvedStatus(existingEntry, period) !== "NOT_PROCESSED" &&
          resolvedStatus(existingEntry, period) !== "DRAFT") {
        skipped.push({employeeCode:employee.employeeCode,reason:"Employee payroll is locked"});
        continue;
      }
      const updatedEntry = await PayrollEntry.findOneAndUpdate(
        existingEntry
          ? {_id:existingEntry._id, status:existingEntry.status || {$exists:false}}
          : {period:period.id,employee:employee._id},
        {
          $set: {
            employeeCode: employee.employeeCode,
            employeeName:
              `${employee.firstName} ${employee.lastName}`,
            calendarDays,
            payableDays: a.payableDays,
            status: "DRAFT",

            // This field retains the original monthly
            // budget; it is now interpreted as monthly CTC.
            monthlyGrossPaise: toPaise(salary.monthlyGross.toString()),

            earnedGrossPaise: earnedGrossPaise + extraEarningsPaise,
            overtimePaise,
            components,
            deductions,
            employerContributions,
            totalDeductionPaise,
            netPaise,

            attendanceSnapshot: {
              ...attendance,
              ...a,
              earnedCtcPaise,
              operationalEarnings: {overtimePaise,outstationPaise},
              operationalDeductions: {insurancePaise:insurance?.amountPaise||0,advancePaise,earlyPenaltyPaise,sitePenaltyPaise},
            },

            policySnapshot: {
              ...policy,
              eligibility,
              pfBasis: "BASIC",
              salaryBasis: "CTC_INCLUSIVE_EMPLOYER_PF",
              employerPfIncludedInCtc: true,
            },

            salaryRevision: salary.revision,
            ruleSnapshot: rules.map(r => ({
              code: r.code,
              mode: r.mode,
              value: r.value,
              effectiveFrom: r.effectiveFrom,
            })),
          },
        },
        { upsert: !existingEntry, new: true, runValidators: true }
      );
      if (!updatedEntry) throw fail("Payroll status changed; refresh and retry",409);
      calculated++;
    }


    await audit(
      req, "CALCULATE", "PayrollMonth", period.id,
      null, { year, month, calculated, skipped: skipped.length }
    );

    res.json({ period, calculated, skipped });
  })
);

// ====================================================
// EMPLOYEE-WISE SUBMISSION AND APPROVAL
// ====================================================
router.post("/period/:year/:month/employee/:employeeId/submit", permit("salary:write"), wrap(async(req,res)=>{
  const {year,month}=ym.parse(req.params);
  const period=await PayrollMonth.findOne({year,month});
  if(!period)throw fail("Payroll period not found",404);
  const entry=await PayrollEntry.findOne({period:period._id,employee:req.params.employeeId}).lean();
  if(!entry || resolvedStatus(entry,period)!=="DRAFT")throw fail("Draft employee payroll not found",409);
  const updated=await PayrollEntry.findOneAndUpdate({_id:entry._id,status:"DRAFT"},{$set:{status:"PENDING_APPROVAL",submittedBy:req.user._id,submittedAt:new Date()}},{new:true});
  if(!updated)throw fail("Payroll status changed; refresh and retry",409);
  await audit(req,"SUBMIT","PayrollEntry",updated.id,{status:"DRAFT"},{status:"PENDING_APPROVAL",year,month,employeeId:req.params.employeeId});
  res.json(updated);
}));

router.post("/period/:year/:month/employee/:employeeId/approve", permit("salary:write"), wrap(async(req,res)=>{
  if(!["ADMIN","SUPER_ADMIN"].includes(req.user.role.code))throw fail("Admin approval required",403);
  const {year,month}=ym.parse(req.params);
  const period=await PayrollMonth.findOne({year,month});
  if(!period)throw fail("Payroll period not found",404);
  const entry=await PayrollEntry.findOneAndUpdate({period:period._id,employee:req.params.employeeId,status:"PENDING_APPROVAL"},{$set:{status:"APPROVED",approvedBy:req.user._id,approvedAt:new Date()}},{new:true});
  if(!entry)throw fail("Employee payroll must be submitted first",409);
  await audit(req,"APPROVE","PayrollEntry",entry.id,{status:"PENDING_APPROVAL"},{status:"APPROVED",year,month,employeeId:req.params.employeeId});
  res.json(entry);
}));

// Do not allow the legacy bulk endpoints to bypass employee-wise approval.
router.post("/period/:year/:month/submit", permit("salary:write"), (_req,res)=>{
  res.status(409).json({message:"Use employee-wise submit endpoint"});
});
router.post("/period/:year/:month/approve", permit("salary:write"), (_req,res)=>{
  res.status(409).json({message:"Use employee-wise approve endpoint"});
});

export default router;

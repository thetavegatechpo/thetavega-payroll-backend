import { Router } from 'express';
import jwt from 'jsonwebtoken';
import { randomUUID } from 'node:crypto';
import rateLimit from 'express-rate-limit';
import { z } from 'zod';
import { Employee } from '../models/index.js';
import MobileOtpChallenge from '../models/MobileOtpChallenge.js';
import MobileDeviceSession from '../models/MobileDeviceSession.js';
import { authenticateMobile, hashToken } from '../middleware/mobileAuth.js';
import { otpServiceAvailable, newOtp, otpDigest, equalOtpHash, sendOtp } from '../services/mobileOtp.js';
import { asyncHandler as wrap } from '../utils/asyncHandler.js';

const router = Router();
const mobileSchema = z.object({ mobile: z.string().regex(/^[6-9]\d{9}$/) }).strict();
const verifySchema = mobileSchema.extend({ otp: z.string().regex(/^\d{6}$/) }).strict();
const generic = { message: 'If this mobile is eligible, an OTP has been requested.' };
const sendLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 5, standardHeaders: 'draft-7', legacyHeaders: false });
const verifyLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 15, standardHeaders: 'draft-7', legacyHeaders: false });

// Existing employee phone numbers may be stored as 10-digit or +91-prefix strings.
// If more than one active record matches, fail closed without exposing employee details.
const candidates = mobile => [mobile, `+91${mobile}`, `91${mobile}`];
async function uniqueActiveEmployee(mobile) {
  const found = await Employee.find({ mobile: { $in: candidates(mobile) }, status: 'ACTIVE' }).select('_id employeeCode firstName lastName mobile').limit(2);
  return found.length === 1 ? found[0] : null;
}

router.post('/send-otp', sendLimiter, wrap(async (req, res) => {
  const parsed = mobileSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ message: 'Enter a valid 10-digit Indian mobile number' });
  if (!otpServiceAvailable()) return res.status(503).json({ message: 'OTP delivery is not configured. Contact administrator.' });
  const { mobile } = parsed.data;
  const employee = await uniqueActiveEmployee(mobile);
  if (!employee) return res.json(generic);
  const recent = await MobileOtpChallenge.findOne({ mobile, createdAt: { $gt: new Date(Date.now() - 60_000) } });
  if (recent) return res.json(generic);
  const otp = newOtp();
  const challenge = await MobileOtpChallenge.create({ mobile, otpHash: otpDigest(mobile, otp), expiresAt: new Date(Date.now() + 5 * 60_000) });
  try { await sendOtp(mobile, otp); }
  catch (error) { await MobileOtpChallenge.deleteOne({ _id: challenge._id }); throw error; }
  res.json(generic);
}));

router.post('/verify-otp', verifyLimiter, wrap(async (req, res) => {
  const parsed = verifySchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ message: 'Invalid mobile or OTP format' });
  if (!otpServiceAvailable()) return res.status(503).json({ message: 'OTP verification unavailable' });
  const { mobile, otp } = parsed.data;
  const challenge = await MobileOtpChallenge.findOne({ mobile, usedAt: null, expiresAt: { $gt: new Date() }, attempts: { $lt: 5 } }).select('+otpHash').sort({ createdAt: -1 });
  if (!challenge) return res.status(401).json({ message: 'Invalid or expired OTP' });
  const correct = equalOtpHash(challenge.otpHash, otpDigest(mobile, otp));
  if (!correct) {
    await MobileOtpChallenge.updateOne({ _id: challenge._id, usedAt: null, attempts: { $lt: 5 } }, { $inc: { attempts: 1 } });
    return res.status(401).json({ message: 'Invalid or expired OTP' });
  }
  // Consume once atomically, preventing simultaneous successful verification.
  const claimed = await MobileOtpChallenge.findOneAndUpdate({ _id: challenge._id, usedAt: null, attempts: { $lt: 5 }, expiresAt: { $gt: new Date() } }, { $set: { usedAt: new Date() } }, { new: true });
  if (!claimed) return res.status(401).json({ message: 'Invalid or expired OTP' });
  const employee = await uniqueActiveEmployee(mobile);
  if (!employee) return res.status(401).json({ message: 'Employee access unavailable' });
  if (!process.env.MOBILE_JWT_SECRET || process.env.MOBILE_JWT_SECRET.length < 32) throw new Error('MOBILE_JWT_SECRET must be at least 32 characters');
  const token = jwt.sign({ tokenType: 'employee' }, process.env.MOBILE_JWT_SECRET, { algorithm: 'HS256', subject: String(employee._id), issuer: 'thetavega-payroll', audience: 'thetavega-mobile', expiresIn: '8h', jwtid: randomUUID() });
  await MobileDeviceSession.create({ employee: employee._id, tokenHash: hashToken(token), expiresAt: new Date(Date.now() + 8 * 60 * 60_000) });
  res.json({ token, tokenType: 'Bearer', expiresInSeconds: 28800, employee: { id: String(employee._id), employeeCode: employee.employeeCode, name: `${employee.firstName} ${employee.lastName}`.trim() } });
}));

router.get('/me', authenticateMobile, wrap(async (req, res) => {
  const employee = await Employee.findById(req.mobileEmployee._id).select('employeeCode firstName lastName mobile department designation status').populate('department', 'code name').populate('designation', 'code name');
  res.json({ employee: { id: String(employee._id), employeeCode: employee.employeeCode, firstName: employee.firstName, lastName: employee.lastName, mobile: employee.mobile, department: employee.department, designation: employee.designation } });
}));

router.post('/logout', authenticateMobile, wrap(async (req, res) => {
  await MobileDeviceSession.updateOne({ _id: req.mobileSession._id, revokedAt: null }, { $set: { revokedAt: new Date() } });
  res.json({ message: 'Logged out' });
}));
export default router;
